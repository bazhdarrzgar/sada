#!/bin/bash
cd /app
exec yarn start